clc,clear;
a=textread('F:\char1.txt')��
corrcoef(a)��
d=pdist(a','correlation')��
z=linkage(d,'average')��
h=dendrogram(z)��
set(h,'color','k','linewidth',1.3)��
T=cluster(z,'maxclust',4)
for i=1:4
tm=find(T==i)
tm=reshape(tm,1,length(tm))
fprintf('%d categary has %s\n',i,int2str(tm))
end