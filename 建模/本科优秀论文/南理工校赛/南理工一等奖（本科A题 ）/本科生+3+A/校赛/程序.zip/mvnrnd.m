clear clc close all
warning off
feature jit off
randn('seed',0);
m=[0,0]';
S=[0.6 1;1 4];
N=1000;
X=mvnrnd(m,S,N)';
figure(3),plot(X(1,:),X(2,:),'.');
axis equal
grid on
axis([-5 5 -5 5])
>> clear clc close all
warning off
feature jit off
randn('seed',0);
m=[0,0]';
S=[0.6 -1;-1 4];
N=1000;
X=mvnrnd(m,S,N)';
figure(3),plot(X(1,:),X(2,:),'.');
axis equal
grid on
axis([-5 5 -5 5])